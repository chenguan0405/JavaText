package com.study.PetGame;

import java.util.Random;

/**  
  * 书写 派生类 (Dog类) 里 特性的代码
  * @author chy 
  * @date 24 Sep 2019 14:39:42 
  * @version 1.0  
*/

public class Dog extends Pet {
	
	public void walk() {
		System.out.println("Walk Walk Walk!");
		System.out.println("Your dog is happy!");
		
		Random random = new Random();
		int val = 5 + random.nextInt(5);
		this.energy -= val;
		this.happiness += val * 5;
		
		this.computerLevel();
	}

	// 与 基类 中的 Play() 方法 构成 重载
	public void Play(PetToy toy) {
		if(toy == PetToy.BONE) {
			this.happiness += 10;
		} else if(toy == PetToy.FISH) {
			System.out.println("Your dog dislike this fish!");
			this.happiness -= 10;
		} else {
			super.Play();  // 调用基类的 Play()  譬如：玩滑梯
		}
	}
}
