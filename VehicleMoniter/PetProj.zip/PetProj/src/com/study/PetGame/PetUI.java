package com.study.PetGame;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JTextField;

@SuppressWarnings("serial")
public class PetUI extends JFrame {

	private Pet myPet;
	private JButton btnFeed;
	private JButton btnPlay;
	
	private JPanel contentPane;
	private JTextField txtName;
	private JTextField txtPetName;
	private JTextField txtAdoptDate;
	private JTextField txtLevel;
	private JTextField txtHappiness;
	private JTextField txtEnergy;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PetUI frame = new PetUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PetUI() {
		
		// ��������JButton����Ϊ�����еľֲ����������ڶ������¿��ã����ϲ�����
//		JButton btnFeed = new JButton("Feed");
//		btnFeed.setEnabled(false);
//		btnFeed.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				myPet = new Pet();
//				myPet.Feed();
//				
//				txtLevel.setText(String.valueOf(myPet.level));
//				txtHappiness.setText(String.valueOf(myPet.happiness));
//				txtEnergy.setText(String.valueOf(myPet.energy));
//				
//			}
//		});
//		btnFeed.setBounds(389, 156, 97, 23);
//		contentPane.add(btnFeed);
//		
//		JButton btnPlay = new JButton("Play");
//		btnPlay.setEnabled(false);
//		btnPlay.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				myPet = new Pet();
//				myPet.Play();
//				
//				txtLevel.setText(String.valueOf(myPet.level));
//				txtHappiness.setText(String.valueOf(myPet.happiness));
//				txtEnergy.setText(String.valueOf(myPet.energy));
//				
//			}
//		});
//		btnPlay.setBounds(389, 214, 97, 23);
//		contentPane.add(btnPlay);
		
		setTitle("PetGame");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 639, 509);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setBounds(59, 59, 58, 15);
		contentPane.add(label);
		
		txtName = new JTextField();
		txtName.setBounds(129, 77, 105, 21);
		contentPane.add(txtName);
		txtName.setColumns(10);
		
		JLabel lblPetName = new JLabel("Pet Name:");
		lblPetName.setBounds(59, 77, 74, 21);
		contentPane.add(lblPetName);
		
		JButton btnAdopt = new JButton("Adopt");
		btnAdopt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {  // ���Ӱ�ť�����¼�
				String name = txtName.getText();
				myPet = new Pet(name);
				
				// ���ı�����������Ϣ
				txtPetName.setText(myPet.name);  
				txtAdoptDate.setText(String.format("%tY-%<tm-%<td %<tH:%<tM:%<tS", myPet.adoptDate));

				txtLevel.setText(String.valueOf(myPet.level));
				txtHappiness.setText(String.valueOf(myPet.happiness));
				txtEnergy.setText(String.valueOf(myPet.energy));
				
				// ���� ��ť ����
				btnPlay.setEnabled(true);
				btnFeed.setEnabled(true);
			}
		});
		btnAdopt.setBounds(262, 76, 97, 23);
		contentPane.add(btnAdopt);
		
		JLabel lblPet = new JLabel("Pet Name:");
		lblPet.setBounds(59, 130, 74, 21);
		contentPane.add(lblPet);
		
		txtPetName = new JTextField();
		txtPetName.setEditable(false);
		txtPetName.setColumns(10);
		txtPetName.setBounds(129, 130, 105, 21);
		contentPane.add(txtPetName);
		
		JLabel lblAdoptDate = new JLabel("Adopt Date:");
		lblAdoptDate.setBounds(59, 182, 74, 21);
		contentPane.add(lblAdoptDate);
		
		txtAdoptDate = new JTextField();
		txtAdoptDate.setEditable(false);
		txtAdoptDate.setColumns(10);
		txtAdoptDate.setBounds(129, 182, 105, 21);
		contentPane.add(txtAdoptDate);
		
		JLabel lblLevel = new JLabel("Level:");
		lblLevel.setBounds(59, 234, 74, 21);
		contentPane.add(lblLevel);
		
		txtLevel = new JTextField();
		txtLevel.setEditable(false);
		txtLevel.setColumns(10);
		txtLevel.setBounds(129, 234, 105, 21);
		contentPane.add(txtLevel);
		
		JLabel lblHappiness = new JLabel("Happiness:");
		lblHappiness.setBounds(59, 274, 74, 21);
		contentPane.add(lblHappiness);
		
		txtHappiness = new JTextField();
		txtHappiness.setEditable(false);
		txtHappiness.setColumns(10);
		txtHappiness.setBounds(129, 274, 105, 21);
		contentPane.add(txtHappiness);
		
		JLabel lblEnergy = new JLabel("Energy:");
		lblEnergy.setBounds(59, 318, 74, 21);
		contentPane.add(lblEnergy);
		
		txtEnergy = new JTextField();
		txtEnergy.setEditable(false);
		txtEnergy.setColumns(10);
		txtEnergy.setBounds(129, 318, 105, 21);
		contentPane.add(txtEnergy);
		
		// ������� (ͬһ��������)��������˸ð�ť����ð�ťӦ����Ϊ �������
		btnFeed = new JButton("Feed");
		btnFeed.setEnabled(false);
		btnFeed.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//				myPet = new Pet();  // �мǴ���䲻�����ӣ��������ָ����-->ÿ��Feed��Ҫ�����µĶ���
				myPet.Feed();
				
				txtLevel.setText(String.valueOf(myPet.level));
				txtHappiness.setText(String.valueOf(myPet.happiness));
				txtEnergy.setText(String.valueOf(myPet.energy));
				
			}
		});
		btnFeed.setBounds(389, 156, 97, 23);
		contentPane.add(btnFeed);
		
		btnPlay = new JButton("Play");
		btnPlay.setEnabled(false);
		btnPlay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				myPet.Play();
				
				txtLevel.setText(String.valueOf(myPet.level));
				txtHappiness.setText(String.valueOf(myPet.happiness));
				txtEnergy.setText(String.valueOf(myPet.energy));
				
			}
		});
		btnPlay.setBounds(389, 214, 97, 23);
		contentPane.add(btnPlay);
	}
}
