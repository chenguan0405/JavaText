package com.study.PetGame;

/** 
    * ö���� 
  * @author chy 
  * @date 24 Sep 2019 15:26:58 
  * @version 1.0  
*/

public enum PetToy {
	BONE,
	FISH;
}
