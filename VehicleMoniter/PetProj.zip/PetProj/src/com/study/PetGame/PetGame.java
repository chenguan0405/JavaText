package com.study.PetGame;

import java.io.IOException;
import java.util.Scanner;

public class PetGame {
	
//	private Pet myPet = new Pet();  // �ڿ�ʼ ��Ϸ֮ǰ �ʹ�������
//	private Dog myPet = new Dog();
	private Cat myPet = new Cat();
	
	public void runGame() throws IOException, InterruptedException {  // IO���쳣���߳��쳣
																	  // ����ڷ��������ź����׳�һ���쳣��
		                                                              // ��ô�÷����ĵ����߱��� ������쳣(�� ���쳣�����׳�)
		
		int sel = -1;
		while (sel != 0) {                                                                       
			// show a menu
			System.out.println("*************Pet Game*************");
			System.out.println("Option:");
			System.out.println("	1 -- Adopt new cat");
			System.out.println("	2 -- Change your pets name");
			System.out.println("	3 -- Show your pet infomation");
			System.out.println("	4 -- Playing with your pet");
			System.out.println("	5 -- Feed your pet");
			System.out.println("	6 -- With your a walk");
			System.out.println("	7 -- Play with a tone toy");
			System.out.println("	8 -- Play with a fish toy");
			System.out.println("	0 -- Exit");
			System.out.println("********************************");
			
			//choose a option
			@SuppressWarnings("resource")  // ���� û�� .close() ��������
			Scanner scanner = new Scanner(System.in);
			
			do {
				try {
					System.out.println("Please input your select : \n");
					sel = scanner.nextInt();
					// ��������ϵͳ����
					new ProcessBuilder("cmd" , "/c", "pause").inheritIO().start().waitFor();  // ���Կ���� ���
				}catch(Exception ex) {
					ex.printStackTrace();
				}
				
			}while(sel < 0 || sel > 8);
			// scanner.close();
			
			
			switch(sel) {
			case 0:
				System.out.println("Thanks and Bye");
				System.exit(0);  // �˳�����
				break;
			case 1:
				myPet.Adopt();
				myPet.showInfo();
				break;
			case 2: 
				myPet.setName();
				myPet.showInfo();
				break;
			case 3:
				myPet.showInfo();
				break;
			case 4:
				myPet.Play();
				break;
			case 5:
				myPet.Feed();
				break;
			case 6:
//				myPet.walk();
				myPet.computerLevel();
				break;
			case 7:
				myPet.Play(PetToy.BONE);
				myPet.computerLevel();
				break;
			case 8:
				myPet.Play(PetToy.FISH);
				myPet.computerLevel();
				break;
			
			default:
				System.out.println("Wrong choice!");
			}
			
//			try {
//				new ProcessBuilder("cmd", "/c", "pause").inheritIO().start().waitFor();
//			} catch(InterruptedException ex) {
//				ex.printStackTrace();
//			}
		}

	}
}
